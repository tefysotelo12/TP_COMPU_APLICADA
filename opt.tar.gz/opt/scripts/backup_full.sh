#! /bin/bash

BACKUP=$1
NOMBRE=$2
FECHA=$(date +%Y%m%d)
ARCHIVOBKP=/backup_dir

echo "Agregue -help como argumento si desea instrucciones paso por paso."
if [[ $BACKUP == "-help" ]]; then
	echo "Invoque el scrip y agregue como primer argumento el PATH del archivo a respaldar y como segundo argumento el nombre que desea darle al archivo tar."
	read -p "Ingrese el PATH de la carpeta a respaldar" BACKUP
	read -p "Ingrese el nombre que le quiera dal al archivo tar" NOMBRE
fi


if [[ -e "$BACKUP" ]] && [[ $BACKUP != "-help" ]] && [[NOMBRE != "" ]] && [[ -d "$ARCHIVOBKP" ]]; then
	NOMBREARCHIVO=""$NOMBRE"_bkp_"$FECHA".tar.gz"
	tar cpzvf "$ARCHIVOBKP"/"$NOMBREARCHIVO" "$BACKUP";

	if [[ -f "$ARCHIVOBKP/$NOMBREARCHIVO" ]]; then
		echo "El backup de $BACKUP se realizó con éxito.";

	else
		echo "No se pudo realizar el backup de $BACKUP".;
	fi

else
	echo "No se pudo realizar el backup de $BACKUP porque el archivo o la carpeta de destino $ARCHIVOBKP no existen.";

fi


#HELP
#Para realizar el backup de un archivo, invocar el script /opt/scripts/backup_full.sh
#e ingresar como primer argumento el path del archivo que se desea respaldar
#y el nombre de archivo para identificarlo que se le desea dar al archivo comprimido.

#Ejemplo:
#/opt/scripts/backup_full.sh /var/logs logs
#
#Generará como respuesta un archivo gz llamado logs_bkp_250603.tar.gz
#si fue realizado el 03/06/2025.
